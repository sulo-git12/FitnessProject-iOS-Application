//
//  RMSettingsViewController.swift
//  Epicurious Chef
//
//  Created by Sulo Mac on 1/30/23.
//

import UIKit

// controller to show settings
final class RMSettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Settings"
    }


   

}
