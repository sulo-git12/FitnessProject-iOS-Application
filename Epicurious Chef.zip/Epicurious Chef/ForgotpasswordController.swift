//
//  ForgotpasswordController.swift
//  Epicurious Chef
//
//  Created by Sulo Mac on 1/18/23.
//

import UIKit

class ForgotpasswordController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = .systemRed
    }
    
}
