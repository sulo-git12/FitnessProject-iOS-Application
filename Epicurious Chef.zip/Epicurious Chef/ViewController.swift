//
//  ViewController.swift
//  Epicurious Chef
//
//  Created by Sulo Mac on 1/18/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .systemBlue
        
    }


}

